package framexpert.run.oltp.sample.ec.qc;

import java.util.List;

import framexpert.run.oltp.sample.ec.qc.vo.PersonQcVo;
import framexpert.run.oltp.sample.ec.tc.vo.SocialSecurityNumberTcVo;

public interface PersonQc {

	public List<PersonQcVo> getPersons(SocialSecurityNumberTcVo ssn);
	
	public List<PersonQcVo> getPersonsDynamic(PersonQcVo personVo);
}
