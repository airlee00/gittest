package framexpert.run.oltp.sample.ec.qc.impl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import framexpert.run.oltp.ext.jdbc.AbstractJdbcDaoSupport;
import framexpert.run.oltp.ext.jdbc.DynamicSqlQueryConverter;
import framexpert.run.oltp.sample.ec.qc.PersonQc;
import framexpert.run.oltp.sample.ec.qc.vo.PersonQcVo;
import framexpert.run.oltp.sample.ec.tc.vo.SocialSecurityNumberTcVo;

@Repository
public class PersonQcImpl extends AbstractJdbcDaoSupport implements PersonQc {

	@Override
    protected String getDataSourceName() {
	    return "bizDataSource02";
    }
	
	@Override
	public List<PersonQcVo> getPersons(SocialSecurityNumberTcVo ssn) {
		  StringBuilder sql = new StringBuilder();
	        sql.append(" /*SQL_ID: framexpert-run-oltp-sample-getPersons */\n");
	        sql.append(" select a.SSN as ssn,       \n");
            sql.append("	a.NAME as name,        \n");
            sql.append("	b.zip_code zipCode,    \n");
            sql.append("	b.address1 address1,   \n");
            sql.append("	b.address2 address2    \n");
            sql.append(" from PERSON a,             \n");
            sql.append("  	  ADDRESS b             \n");
            sql.append(" where SSN = :value         \n");

            
            return (List<PersonQcVo>) query(sql.toString(), ssn, new RowMapper<PersonQcVo>() {
                public PersonQcVo mapRow(ResultSet rs, int row) throws SQLException {

                	PersonQcVo returnVO = new PersonQcVo();
                	returnVO.setSsn(rs.getString("SSN"));
                	returnVO.setName(rs.getString("NAME"));
                	returnVO.setZipCode(rs.getString("ZIPCODE"));
                	returnVO.setAddress1(rs.getString("ADDRESS1"));
                	returnVO.setAddress2(rs.getString("ADDRESS2"));
                    return returnVO;
                }
            });
            
	}
	
	@Override
	public List<PersonQcVo> getPersonsDynamic(PersonQcVo personVo) {
		StringBuilder sql = new StringBuilder();
		
		sql.append(" select /*SQL_ID: framexpert-run-oltp-sample-getPersonsDynamic */\n");
		sql.append("    a.SSN as ssn,             \n");
		sql.append("	a.NAME as name,            \n");
		sql.append("	b.zip_code zipCode,        \n");
		sql.append("	b.address1 address1,       \n");
		sql.append("	b.address2 address2        \n");
		sql.append(" from PERSON a,                \n");
		sql.append("  	  ADDRESS b                \n");
		sql.append(" where b. zip_code= :zipCode   \n");
		sql.append(" #if($address1 && !$address1.equals(\"\"))  \n");
		sql.append("     and address1 like '$address1%'  \n");
		sql.append(" #end ");

		//방법1
		//java.util.Map<String, ?> data = convertObjectToMap(personVo);
		//방법2
		java.util.Map<String, Object> data = new java.util.HashMap<String,Object>();
		data.put("address1", personVo.getAddress1());
		
		 String sqlString = DynamicSqlQueryConverter.convertDynamicQuery(sql.toString(), data);
		
		return (List<PersonQcVo>) query(sqlString, personVo, new RowMapper<PersonQcVo>() {
			public PersonQcVo mapRow(ResultSet rs, int row) throws SQLException {
				
				PersonQcVo returnVO = new PersonQcVo();
				returnVO.setSsn(rs.getString("SSN"));
				returnVO.setName(rs.getString("NAME"));
				returnVO.setZipCode(rs.getString("ZIPCODE"));
				returnVO.setAddress1(rs.getString("ADDRESS1"));
				returnVO.setAddress2(rs.getString("ADDRESS2"));
				return returnVO;
			}
		});
		
	}



}
