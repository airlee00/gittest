package framexpert.run.oltp.sample.ec.qc.vo;

import framexpert.run.common.io.type.annotation.CompositeType;
import framexpert.run.common.io.type.annotation.Property;

@CompositeType
public class PersonQcVo {

	@Property(length=13)
	private String ssn;
	@Property(length=20)
	private String name;
	@Property(length=6)
	private String zipCode;
	@Property(length=100)
	private String address1;
	@Property(length=100)
	private String address2;



	public PersonQcVo() {
		super();
	}



	public String getSsn() {
		return ssn;
	}



	public void setSsn(String ssn) {
		this.ssn = ssn;
	}



	public String getName() {
		return name;
	}



	public void setName(String name) {
		this.name = name;
	}



	public String getZipCode() {
		return zipCode;
	}



	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}



	public String getAddress1() {
		return address1;
	}



	public void setAddress1(String address1) {
		this.address1 = address1;
	}



	public String getAddress2() {
		return address2;
	}



	public void setAddress2(String address2) {
		this.address2 = address2;
	}



	@Override
    public int hashCode() {
	    final int prime = 31;
	    int result = 1;
	    result = prime * result + ((address1 == null) ? 0 : address1.hashCode());
	    result = prime * result + ((address2 == null) ? 0 : address2.hashCode());
	    result = prime * result + ((name == null) ? 0 : name.hashCode());
	    result = prime * result + ((ssn == null) ? 0 : ssn.hashCode());
	    result = prime * result + ((zipCode == null) ? 0 : zipCode.hashCode());
	    return result;
    }



	@Override
    public boolean equals(Object obj) {
	    if (this == obj)
		    return true;
	    if (obj == null)
		    return false;
	    if (getClass() != obj.getClass())
		    return false;
	    PersonQcVo other = (PersonQcVo) obj;
	    if (address1 == null) {
		    if (other.address1 != null)
			    return false;
	    } else if (!address1.equals(other.address1))
		    return false;
	    if (address2 == null) {
		    if (other.address2 != null)
			    return false;
	    } else if (!address2.equals(other.address2))
		    return false;
	    if (name == null) {
		    if (other.name != null)
			    return false;
	    } else if (!name.equals(other.name))
		    return false;
	    if (ssn == null) {
		    if (other.ssn != null)
			    return false;
	    } else if (!ssn.equals(other.ssn))
		    return false;
	    if (zipCode == null) {
		    if (other.zipCode != null)
			    return false;
	    } else if (!zipCode.equals(other.zipCode))
		    return false;
	    return true;
    }



	@Override
    public String toString() {
	    return "PersonQcVo [ssn=" + ssn + ", name=" + name + ", zipCode=" + zipCode + ", address1="
	            + address1 + ", address2=" + address2 + "]";
    }


}
