package framexpert.run.oltp.sample.ec.tc;

import java.util.List;

import framexpert.run.oltp.sample.ec.tc.vo.AddressTcVo;



public interface AddressTc {

	public int createAddress(AddressTcVo addressTsoVo);
	
	public int createAddressDynamic(AddressTcVo addressTsoVo);
	
	public List<AddressTcVo> getAddresses(AddressTcVo addressTsoVo);
	
	public int updateAddress(AddressTcVo addressTsoVo);
	
	public int deleteAddress(AddressTcVo addressTsoVo);
	
}
