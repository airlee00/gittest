package framexpert.run.oltp.sample.ec.tc.vo;

import framexpert.run.common.io.type.annotation.CompositeType;
import framexpert.run.common.io.type.annotation.Property;

@CompositeType
public class AddressTcVo {

	private long id;
	
	@Property(length=13)
	private String ssn;
	@Property(length=6)
	private String zipCode;
	@Property(length=100)
	private String address1;
	@Property(length=100)
	private String address2;

	public AddressTcVo() {
		super();
	}

	public AddressTcVo(long id, String ssn, String zipCode, String address1,
			String address2) {
		super();
		this.id = id;
		this.ssn = ssn;
		this.zipCode = zipCode;
		this.address1 = address1;
		this.address2 = address2;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getSsn() {
		return ssn;
	}

	public void setSsn(String ssn) {
		this.ssn = ssn;
	}

	public String getZipCode() {
		return zipCode;
	}

	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}

	public String getAddress1() {
		return address1;
	}

	public void setAddress1(String address1) {
		this.address1 = address1;
	}

	public String getAddress2() {
		return address2;
	}

	public void setAddress2(String address2) {
		this.address2 = address2;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + (int) (id ^ (id >>> 32));
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		AddressTcVo other = (AddressTcVo) obj;
		if (id != other.id)
			return false;
		return true;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("AddressTsoVo [id=").append(id).append(", ssn=").append(ssn)
				.append(", zipCode=").append(zipCode).append(", address1=")
				.append(address1).append(", address2=").append(address2)
				.append("]");
		return builder.toString();
	}

}
