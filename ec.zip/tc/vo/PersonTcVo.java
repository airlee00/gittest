package framexpert.run.oltp.sample.ec.tc.vo;

import java.util.List;

import framexpert.run.common.io.type.annotation.CompositeType;
import framexpert.run.common.io.type.annotation.Property;

@CompositeType
public class PersonTcVo {

	@Property
	private SocialSecurityNumberTcVo ssn;
	@Property(length=13)
	private String value;
	@Property(length=20)
	private String name;
	@Property(length=7)
	private int cntAddress;	
	@Property(maxSize={10})
	private List<AddressTcVo> address;



	public PersonTcVo() {
		super();
	}

	public PersonTcVo(SocialSecurityNumberTcVo ssn, String name, List<AddressTcVo> addressTsoVo) {
		super();
		this.ssn = ssn;
		this.name = name;
		this.address = addressTsoVo;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public SocialSecurityNumberTcVo getSsn() {
		return ssn;
	}

	public void setSsn(SocialSecurityNumberTcVo ssn) {
		this.ssn = ssn;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}


	public int getCntAddress() {
		return cntAddress;
	}

	public void setCntAddress(int cntAddress) {
		this.cntAddress = cntAddress;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((ssn == null) ? 0 : ssn.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		PersonTcVo other = (PersonTcVo) obj;
		if (ssn == null) {
			if (other.ssn != null)
				return false;
		} else if (!ssn.equals(other.ssn))
			return false;
		return true;
	}

	public List<AddressTcVo> getAddress() {
		return address;
	}

	public void setAddress(List<AddressTcVo> address) {
		this.address = address;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("PersonTsoVo [ssn=").append(ssn).append(", name=").append(
				name).append(", addressTsoVo=").append(address).append("]");
		return builder.toString();
	}

}
