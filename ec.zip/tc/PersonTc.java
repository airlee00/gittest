package framexpert.run.oltp.sample.ec.tc;

import framexpert.run.oltp.sample.ec.tc.vo.PersonTcVo;
import framexpert.run.oltp.sample.ec.tc.vo.SocialSecurityNumberTcVo;

public interface PersonTc {

	public PersonTcVo createPerson(PersonTcVo personTsoVo);
	
	public PersonTcVo getPerson(SocialSecurityNumberTcVo ssn);

	public PersonTcVo updatePerson(PersonTcVo personTsoVo);
	
	public PersonTcVo deletePerson(SocialSecurityNumberTcVo ssn);
	
}
