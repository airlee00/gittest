package framexpert.run.oltp.sample.ec.tc.impl;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import framexpert.run.oltp.ext.jdbc.AbstractJdbcDaoSupport;
import framexpert.run.oltp.sample.ec.tc.PersonTc;
import framexpert.run.oltp.sample.ec.tc.vo.PersonTcVo;
import framexpert.run.oltp.sample.ec.tc.vo.SocialSecurityNumberTcVo;

@Repository
public class PersonTcImpl extends AbstractJdbcDaoSupport implements PersonTc {

	@Override
    protected String getDataSourceName() {
	    return "bizDataSource01";
    }

	public PersonTcVo createPerson(PersonTcVo personTsoVo) {
		StringBuffer sql = new StringBuffer();
	    sql.append(" insert into /* framexpert.run.oltp.sample.ec.tc.createPerson */          \n");
	    sql.append("  PERSON (                  \n");
	    sql.append("          SSN,        \n");
	    sql.append("          NAME)       \n");
	    sql.append(" values (      \n");
	    sql.append("          :ssn.value, \n");
	    sql.append("          :name \n");
	    sql.append("        ) \n");
	              
	    updateWithNestedParameter(sql.toString(), personTsoVo);
		return personTsoVo;
	}

	public PersonTcVo deletePerson(SocialSecurityNumberTcVo ssn) {
		StringBuffer sql = new StringBuffer();
	    sql.append("delete /* framexpert.run.oltp.sample.ec.tc.deletePerson */ \n");
	    sql.append("  from PERSON       \n");
	    sql.append(" where SSN = :value \n");
		
	    PersonTcVo personTsoVo = getPerson(ssn);
	    update(sql.toString(), ssn);
		return personTsoVo;
	}

	public PersonTcVo getPerson(SocialSecurityNumberTcVo ssn) {
		StringBuffer sql = new StringBuffer();
	    sql.append(" select /* framexpert.run.oltp.sample.ec.tc.createPerson */    \n");
	    sql.append("        SSN,           \n");
		sql.append("        NAME           \n");
		sql.append("    from PERSON        \n");
		sql.append("   where SSN = :value  \n");
	     
		return (PersonTcVo) queryForObject(sql.toString(), ssn, new RowMapper<PersonTcVo>() {
			public PersonTcVo mapRow(ResultSet resultSet, int row) throws SQLException {
				PersonTcVo returnVO = new PersonTcVo();
				SocialSecurityNumberTcVo ssnVo = new SocialSecurityNumberTcVo();
				ssnVo.setValue(resultSet.getString("SSN"));
				returnVO.setSsn(ssnVo);
				returnVO.setName(resultSet.getString("NAME"));
				return returnVO;
			}
		});
	}

	public PersonTcVo updatePerson(PersonTcVo personTsoVo) {
		StringBuffer sql = new StringBuffer();
	    sql.append(" update PERSON             \n");
	    sql.append("    set NAME = :name       \n");
	    sql.append("  where SSN = :ssn.value   \n"); 
	      
	    updateWithNestedParameter(sql.toString(), personTsoVo);  
		return personTsoVo;
	}



}
