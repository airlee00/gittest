package framexpert.run.oltp.sample.ec.tc.impl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import framexpert.run.oltp.ext.jdbc.AbstractJdbcDaoSupport;
import framexpert.run.oltp.ext.jdbc.DynamicSqlQueryConverter;
import framexpert.run.oltp.sample.ec.tc.AddressTc;
import framexpert.run.oltp.sample.ec.tc.vo.AddressTcVo;



@Repository
public class AddressTcImpl extends AbstractJdbcDaoSupport implements AddressTc {

	@Override
    protected String getDataSourceName() {
	    return "bizDataSource02";
    }
	
	public int createAddress(AddressTcVo addressTsoVo) {
		StringBuffer sql = new StringBuffer();
		
	    sql.append(" insert into /* framexpert.run.oltp.sample.ec.tc.createAddress */  \n");
	    sql.append(" ADDRESS(                                                          \n");
	    sql.append("          SSN,                                                     \n");
	    sql.append("          ZIP_CODE,                                                \n");
	    sql.append("          ADDRESS1,                                                \n");
	    sql.append("          ADDRESS2)                                                \n");
	    sql.append(" values(                                                           \n");
	    sql.append("          :ssn,               \n");
	    sql.append("          :zipCode,           \n");
	    sql.append("          :address1,          \n");
	    sql.append("          :address2           \n");
	    sql.append("  )          \n");
	    
		return update(sql.toString(), addressTsoVo);
	}
	
	public int createAddressDynamic(AddressTcVo addressTsoVo) {
		StringBuffer sql = new StringBuffer();
		
		sql.append(" insert into /* framexpert.run.oltp.sample.ec.tc.createAddressDynamic */  \n");
		sql.append(" ADDRESS(                                                          \n");
		sql.append("          SSN,                                                     \n");
		sql.append("          ZIP_CODE,                                                \n");
		sql.append("     #if($address1 && !$address1.equals(\"\"))                     \n");
		sql.append("          ADDRESS1,                                                \n");
		sql.append("     #end                                                          \n");
		sql.append("     #if($address2 && !$address2.equals(\"\"))                     \n");
		sql.append("          ADDRESS2                                                \n");
		sql.append("     #end                                                          \n");
		sql.append("          )                                                        \n");
		sql.append(" values(                                                           \n");
		sql.append("          :ssn,               \n");
		sql.append("          :zipCode,           \n");
		sql.append("     #if($address1 && !$address1.equals(\"\"))                     \n");
		sql.append("          :address1,                                                \n");
		sql.append("     #end                                                          \n");
		sql.append("     #if($address2 && !$address2.equals(\"\"))                     \n");
		sql.append("          :address2                                                \n");
		sql.append("     #end                                                          \n");		
		sql.append("  )          \n");
		
		
		String sqlString = DynamicSqlQueryConverter.convertDynamicQuery(sql.toString(), this.convertObjectToMap(addressTsoVo));
		return update(sqlString, addressTsoVo);
	}
	
	public List<AddressTcVo> getAddresses(AddressTcVo addressTsoVo) {
		  StringBuffer sql = new StringBuffer();
		  sql.append("select /* framexpert.run.oltp.sample.ec.tc.createAddress */     \n");
		  sql.append("       ID,        \n");
		  sql.append("       SSN,       \n");
		  sql.append("       ZIP_CODE,  \n");
		  sql.append("       ADDRESS1,  \n");
		  sql.append("       ADDRESS2   \n");
		  sql.append("  from ADDRESS    \n");
		  sql.append(" where SSN = :ssn \n");
		  sql.append(" order by ID      \n");
	  
		return (List<AddressTcVo>) query(sql.toString(), addressTsoVo, new RowMapper<AddressTcVo>() {
			public AddressTcVo mapRow(ResultSet rs, int row) throws SQLException {
				
				AddressTcVo returnVO = new AddressTcVo();
				returnVO.setId(rs.getLong("ID"));
				returnVO.setSsn(rs.getString("SSN"));
				returnVO.setZipCode(rs.getString("ZIP_CODE"));
				returnVO.setAddress1(rs.getString("ADDRESS1"));
				returnVO.setAddress2(rs.getString("ADDRESS2"));
				return returnVO;
			}
		});
		
	}
	
	public int updateAddress(AddressTcVo addressTsoVo) {

		StringBuffer sql = new StringBuffer();
		
	    sql.append(" update /* framexpert.run.oltp.sample.ec.tc.updateAddress */     \n");
	    sql.append("    ADDRESS                 \n");
	    sql.append("    set ZIP_CODE = :zipCode ,  \n");
	    sql.append("        ADDRESS1 = :address1,  \n");
	    sql.append("        ADDRESS2 = :address2   \n");
	    sql.append("  where ID = :id               \n");
	      
		return update(sql.toString(), addressTsoVo);
	}
	
	public int deleteAddress(AddressTcVo addressTsoVo) {
		StringBuffer sql = new StringBuffer();
		sql.append("delete /* framexpert.run.oltp.sample.ec.tc.updateAddress */  \n");
		sql.append(" from ADDRESS  \n");
	    sql.append(" where ID = :id \n");
		
	    return update(sql.toString(), addressTsoVo);
	}
	
}
